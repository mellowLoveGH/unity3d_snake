﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BodyMovie : MonoBehaviour {

    public GameObject body; //下一节身体

    public void MoveTo(Vector3 Pos) 
    {
        Vector3 old = transform.position;
        transform.position = Pos;
        if(body)
        {
            body.GetComponent<BodyMovie>().MoveTo(old);
        }
    }
}
