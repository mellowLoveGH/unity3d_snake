﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snack_Move : MonoBehaviour {

    private float timer = 0f;
    private float time = 0.3f;
    public GameObject food;
    public GameObject body;
    private float food_Max_x = 19f;
    private float food_Max_z = 19f;
    private float food_Min_x = -19f;
    private float food_Min_z = -19f;

    private GameObject firstbody;
    private GameObject lastbody;
    // Use this for initialization
    void Start () {
        RandFood();
    }
	
	// Update is called once per frame
	void Update () {
        if(timer>=time)
        {
            Vector3 oldposition = transform.position;
            transform.position += transform.forward;
            if(firstbody!=null)
            {
                firstbody.GetComponent<BodyMovie>().MoveTo(oldposition);
            }            
            timer = 0;
        }
        timer += Time.deltaTime;
        if((Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow)) && transform.forward != Vector3.back)
        {
            transform.forward = Vector3.forward;//Vector3.forward 世界坐标正前方
        }
        if ((Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow)) && transform.forward != Vector3.forward)
        {
            transform.forward = Vector3.back;
        }
        if ((Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow)) && transform.forward != Vector3.right)
        {
            transform.forward = Vector3.left;
        }
        if ((Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow)) && transform.forward != Vector3.left)
        {
            transform.forward = Vector3.right;
        }     
    }
    void RandFood()//随机生成食物
    {
        float food_x = Random.Range(food_Min_x,food_Max_x);
        float food_z = Random.Range(food_Min_z, food_Max_z);
        float food_y = 0.5f;
        Instantiate(food,new Vector3(food_x,food_y,food_z),Quaternion.identity);
    }

    private void OnTriggerEnter(Collider other)//触发检测
    {
        if(other.tag == "food")//使用标签
        {
            Destroy(other.gameObject);
            RandFood();
            Move();
        }
    }
    void Move()//移动
    {
        GameObject CreateBody = Instantiate(body, new Vector3(100f, 100f, 100f),Quaternion.identity);
        if(lastbody!=null)
        {
            //前一节身体
            lastbody.GetComponent<BodyMovie>().body = CreateBody;
        }

        if(firstbody == null)
        {
            firstbody = CreateBody;
        }
        lastbody = CreateBody;
    }
}
